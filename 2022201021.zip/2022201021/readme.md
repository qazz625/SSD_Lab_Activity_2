## SSD_Lab_Activity_2



#### q1.sh
- `bash q1.sh <file_name>` to run the file. It is recommended to use absolute path for file_name.
- A line with x end line characters is assumed to have x+1 lines
- Example of a file with 4 lines 
> 1 This is line 1
> 2 line 2        
> 3 a             
> 4 b

- Example of a file with 5 lines
> 1 This is line 1
> 2 line 2
> 3 a
> 4 b
> 5





#### q2.sh
- `bash q2.sh` to run the file. The path for the /etc/shells file is hard-coded in the code.



